const express = require('express'),
mongoose = require('mongoose'),
bcrypt = require('bcrypt'),
jwt = require('jsonwebtoken'),
bodyParser = require('body-parser'),
cors = require('cors'),
bearerToken = require('express-bearer-token'),
port = 3050,
app = express();
require('dotenv').config();

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use(cors());
app.use(bearerToken());

mongoose.connect('mongodb://localhost/backjwt', {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true});

AuthController = require('./controllers/auth');
UserController = require('./controllers/user');

app.route('/auth/login').post(AuthController.login);
app.route('/auth/register').post(AuthController.register);

app.route('/users/list').get(UserController.getAll);
app.route('/users/me').get(UserController.getById);


app.listen(port);
